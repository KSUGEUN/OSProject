#include <core/eos.h>
#define STACK_SIZE 8096

/*
static eos_tcb_t tcb1;
static eos_tcb_t tcb2;
static int8u_t stack1[8096];
static int8u_t stack2[8096];



static void print_number(void *arg) {
	while (1) {
	}
}

static void print_alphabet(void *arg) {
	while (1) {
	}
}

void eos_user_main() {
	eos_create_task(&tcb1, (addr_t)stack1, 8096, print_number, NULL, 0);
	eos_create_task(&tcb2, (addr_t)stack2, 8096, print_alphabet, NULL, 0);
}
*/

int32u_t stack1[STACK_SIZE]; // stack for task1
int32u_t stack2[STACK_SIZE]; // stack for task2
eos_tcb_t tcb1; // tcbfor task1
eos_tcb_t tcb2; // tcbfor task2

/* task1 function -print number 1 to 20 repeatedly */
void print_number() {
int i= 0;
while(++i) {
printf("%d", i);
eos_schedule();// \C5½\BAũ1 \BC\F6\C7\E0\C1ߴ\DC, \C5½\BAũ2 \BC\F6\C7\E0\C0簳
if (i== 20) { i= 0; }
}
}
/* task2 function -print alphabet a to z repeatedly */
void print_alphabet() {
int i= 96;
while(++i) {
printf("%c", i);
eos_schedule(); // \C5½\BAũ2 \BC\F6\C7\E0\C1ߴ\DC, \C5½\BAũ1 \BC\F6\C7\E0\C0簳
if (i== 122) { i= 96; }
}
}
void eos_user_main() {
eos_create_task(&tcb1, stack1, STACK_SIZE, print_number, NULL, 0);// \C5½\BAũ1 \BB\FD\BC\BA
eos_create_task(&tcb2, stack2, STACK_SIZE, print_alphabet, NULL, 0);// \C5½\BAũ2 \BB\FD\BC\BA
}
