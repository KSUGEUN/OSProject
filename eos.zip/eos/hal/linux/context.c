#include <core/eos.h>
#include <core/eos_internal.h>

typedef struct _os_context {
	/* low address */

	/* General-Purpose Registers */
	int32u_t	edi;
	int32u_t	esi;
	int32u_t	ebp;
	int32u_t	esp;
	int32u_t	ebx;
	int32u_t	edx;
	int32u_t	ecx;
	int32u_t	eax;
	
	/* Program Status and Control Register */
	int32u_t	eflags;
	
	/* Instruction Pointer */
	int32u_t	eip;

	/* high address */	
} _os_context_t;


// User-define static variable
static int restored;	// if this boolean variable is true,  the context-saving ftn returns NULL.
static addr_t return_value;
static addr_t old_EBP;
static addr_t old_EIP;
static addr_t real_eip;


void print_context(addr_t context) {
	if(context == NULL) return;
	_os_context_t *ctx = (_os_context_t *)context;
	//PRINT("reg1  =0x%x\n", ctx->reg1);
	//PRINT("reg2  =0x%x\n", ctx->reg2);
	//PRINT("reg3  =0x%x\n", ctx->reg3);
	//...
}

addr_t _os_create_context(addr_t stack_base, size_t stack_size, void (*entry)(void *), void *arg) {

/*int i;
	for(i = 1; i < 12; i++){
		if(i == 1){
			*((int32u_t*)stack_base + stack_size/4 - 32/4) = arg;
		}
		else if(i == 3){
			*((int32u_t*)stack_base + stack_size/4 - 32*3/4) = entry;
		}
		else if(i == 10){
			*((int32u_t*)stack_base + stack_size/4 - 10*32/4) = (int32u_t*)stack_base + stack_size/4 - 32/4;
		}
		else if(i == 9){
			*((int32u_t*)stack_base + stack_size/4 - 9*32/4) = (int32u_t*)stack_base + stack_size/4 - 32*8/4;
		}
		else{
			*((int32u_t*)stack_base + stack_size/4 - i*32/4) = NULL;
		}
	}
	return ((int32u_t*)stack_base + stack_size/4 - 12*32/4);*/ 
int i;	
for(i = 1; i < 12; i++){
		if(i == 1){
			*((int32u_t*)stack_base + stack_size - (int32u_t)i) = arg;		
		}
		else if(i == 3){
			*((int32u_t*)stack_base + stack_size - (int32u_t)i) = entry;
		}
		else if(i == 10){
			*((int32u_t*)stack_base + stack_size - (int32u_t)i) = (int32u_t*)stack_base + stack_size - (int32u_t)1;
		}
		else if(i == 9){
			*((int32u_t*)stack_base + stack_size - (int32u_t)i) = (int32u_t*)stack_base + stack_size - (int32u_t)8;
		}
		else{
			*((int32u_t*)stack_base + stack_size - (int32u_t)i) = NULL;
		}
	}
//	PRINT("restored addr1 : %x\n", (int32u_t*)stack_base + stack_size - (int32u_t)12);
//	PRINT("restored addr2 : %x\n", (int32u_t*)stack_base + stack_size);
	//PRINT("restored addr1 : %x\n", (int32u_t*)stack_base + stack_size - (int32u_t)12);
	//PRINT("restored addr1 : %x\n", (int32u_t*)stack_base + stack_size - (int32u_t)12);
	return ((int32u_t*)stack_base + stack_size - (int32u_t)11);
}

void _os_restore_context(addr_t sp) {
	restored = 1;

	__asm__ __volatile__("movl %0, %%esp;" : : "m" (sp));
	__asm__ __volatile__("pop %edi; pop %esi; pop %ebp;  pop %ebx; pop %edx; pop %ecx; pop %eax;");
	__asm__ __volatile__("addl $4, %esp");

	__asm__ __volatile__("ret;");

}

void eip_update(){
	__asm__ __volatile__("movl %ebp, %esp");
	__asm__ __volatile__("pop %eax");
	__asm__ __volatile__("pop %ebx");
	__asm__ __volatile__("movl %%ebx, %0":"=m"(real_eip));
	__asm__ __volatile__("push %ebx");
	__asm__ __volatile__("push %eax");
	__asm__ __volatile__("pop %ebp");
	__asm__ __volatile__("ret");
}

addr_t _os_save_context() {
	restored = 0;	
	__asm__ __volatile__("movl %ebp, %esp;");

	__asm__ __volatile__("pop %0;":"=m"(old_EBP));		// saving old EBP value in the stack to the old_EBP
	__asm__ __volatile__("pop %0;":"=m"(old_EIP));		// saving old EIP value in the stack to the old_EIP
	__asm__ __volatile__("push %0;"::"m"(old_EIP));
	__asm__ __volatile__("push %0;"::"m"(old_EBP));
	__asm__ __volatile__("subl $4, %esp;");		//pass
	__asm__ __volatile__("push $0;");		//push NULL to eflags
	__asm__ __volatile__("push %eax; push %ecx; push %edx; push %ebx;  push %ebp; push %esi; push %edi;");
	__asm__ __volatile__("movl %esp, %eax;");
	__asm__ __volatile__("movl %%eax, %0":"=m"(return_value));
	__asm__ __volatile__("push %0;"::"m"(old_EIP));
	__asm__ __volatile__("push %0;"::"m"(old_EBP));
	__asm__ __volatile__("movl %esp, %ebp");	
	eip_update();
	__asm__ __volatile__("movl %0, %%eax"::"m"(restored));
	__asm__ __volatile__("movl $0, %ebx");
	__asm__ __volatile__("cmp %eax, %ebx");
	__asm__ __volatile__("je _saved; "
				"movl $0, %0;":"=m"(return_value)
	);
	__asm__ __volatile__("jne _restored;");
	//__asm__ __volatile__("movl %0, %%ebx"::"m"(return_value));
	__asm__ __volatile__("_saved : movl %0, %%eax; movl %%eax, 40(%%ebp);"::"m"(real_eip)
	);	
__asm__ __volatile__("_restored :;");

	return return_value;
	//__asm__ __volatile__("movl %%eax, %0":"=m"(return_value));

	//return return_value;


	


					// else if the context is restored, then return NULL.
}
