/********************************************************
 * Filename: core/timer.c
 *
 * Author: wsyoo, RTOSLab. SNU.
 * 
 * Description: 
 ********************************************************/
#include <core/eos.h>

static eos_counter_t system_timer;

int8u_t eos_init_counter(eos_counter_t *counter, int32u_t init_value) {
	counter->tick = init_value;
	counter->alarm_queue = NULL;
	return 0;
}

void eos_set_alarm(eos_counter_t* counter, eos_alarm_t* alarm, int32u_t _timeout, void (*entry)(void *arg), void *arg) {
	//1.
	if (counter->alarm_queue != NULL){
		_os_node_t* temp = counter->alarm_queue;
		if(temp->ptr_data == alarm){
			if(counter->alarm_queue->next != NULL){
				counter->alarm_queue = counter->alarm_queue->next;
				counter->alarm_queue->previous = NULL;
			}
			else counter->alarm_queue = NULL;
			free(alarm);
			return;
		}
	}
	//2.
	if (_timeout == 0 || entry == NULL) {
		return;
	}
	//3.
	alarm->timeout = _timeout;
	alarm->handler = entry;
	alarm->arg = arg;
	alarm->alarm_queue_node.ptr_data = alarm;

	//4.
	_os_node_t *cursor = counter->alarm_queue;
	if (cursor == NULL) {
		counter->alarm_queue = &(alarm->alarm_queue_node);
	}
	else {
		eos_alarm_t *tmp = cursor->ptr_data;
		while (cursor->next != NULL){
			if(tmp->timeout < _timeout) {
				cursor = cursor -> next;
			}

			else if(tmp->timeout == _timeout){
				if(alarm->alarm_queue_node._priority < tmp->alarm_queue_node._priority)	break;
				else cursor = cursor -> next;
			}
			else break;
			tmp = cursor->ptr_data;
		}

		if(cursor->next == NULL && tmp->timeout < _timeout){
			cursor->next = &alarm->alarm_queue_node;
			alarm->alarm_queue_node.previous = cursor;
			alarm->alarm_queue_node.next = NULL;
		}
		else if(cursor->previous == NULL){
			counter->alarm_queue = &(alarm->alarm_queue_node);
			counter->alarm_queue->next = cursor;
			cursor->previous = counter->alarm_queue;		
		}
		else{
			_os_node_t *temp = cursor;
			cursor = cursor->previous;
			cursor->next = &alarm->alarm_queue_node;
			alarm->alarm_queue_node.previous = cursor;
			alarm->alarm_queue_node.next = temp;
			temp->previous = &alarm->alarm_queue_node;
		}
	}
}

eos_counter_t* eos_get_system_timer() {
	return &system_timer;
}

void eos_trigger_counter(eos_counter_t* counter) {
	//1.
	counter->tick += 1;
	//2.
	_os_node_t *cur = counter->alarm_queue;
	eos_alarm_t *temp_alarm = cur->ptr_data; 

	while (temp_alarm->timeout <= counter->tick) {
		if(cur->next != NULL){
			cur= cur->next;
		}
	void (*temp)(void *temp_arg) = temp_alarm->handler;
	void *temp_arg = temp_alarm->arg;
		eos_set_alarm(counter, temp_alarm, 0, NULL, NULL);
		if (temp_alarm->handler != NULL){
			temp(temp_arg);
		}
		temp_alarm = cur->ptr_data;
		if(cur->next == NULL) break;
	}
	PRINT("tick\n");
}

/* Timer interrupt handler */
static void timer_interrupt_handler(int8s_t irqnum, void *arg) {
	/* trigger alarms */
	eos_trigger_counter(&system_timer);
}

void _os_init_timer() {
	eos_init_counter(&system_timer, 0);

	/* register timer interrupt handler */
	eos_set_interrupt_handler(IRQ_INTERVAL_TIMER0, timer_interrupt_handler, NULL);
}
