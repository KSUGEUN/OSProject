/********************************************************
 * Filename: core/comm.c
 *  
 * Author: jtlim, RTOSLab. SNU.
 * 
 * Description: message queue management. 
 ********************************************************/
#include <core/eos.h>

void eos_init_mqueue(eos_mqueue_t *mq, void *queue_start, int16u_t queue_size, int8u_t msg_size, int8u_t queue_type) {
	mq->queue_start = queue_start;
	mq->front = queue_start;
	mq->rear = queue_start;
	mq->queue_size = queue_size;
	mq->msg_size = msg_size;
	mq->queue_type = queue_type;
	eos_init_semaphore(&(mq->putsem), queue_size, queue_type);
	eos_init_semaphore(&(mq->getsem), 0, queue_type);
}

int8u_t eos_send_message(eos_mqueue_t *mq, void *message, int32s_t timeout) {
//	PRINT("TEST1\n");
//		PRINT("message: %s\n", message);
	eos_acquire_semaphore(&(mq->putsem), timeout);
	int i = 0;
	while(i < mq->msg_size){
		*((int8u_t*)(mq->rear) + i) = *((int8u_t*)(message) + i);
		i++;
	}
//		PRINT("message: %s\n", (int8u_t*)(mq->front));
	(mq->rear) = (mq->rear) + mq->msg_size;
	eos_release_semaphore(&(mq->getsem));
}

int8u_t eos_receive_message(eos_mqueue_t *mq, void *message, int32s_t timeout) {
//	PRINT("TEST2\n");

	eos_acquire_semaphore(&(mq->getsem), timeout);
//	PRINT("acquired\n");
	int8u_t temp[mq->msg_size];
	int i = 0;
	while(i < mq->msg_size){
		*((int8u_t*)message + i) = *((int8u_t*)(mq->front) + i);
		i++;
	}
	(mq->front) = (mq->front) + mq->msg_size;
	eos_release_semaphore(&(mq->putsem));
}
